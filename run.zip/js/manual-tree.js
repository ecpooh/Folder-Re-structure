(function (global) {
  const MANUAL_LEAVES = [
    { code: "A", name: "Productivity", path: "A - Productivity" },
    { code: "A1", name: "Personal", path: "A - Productivity / A1 Personal", parent: "A" },
    { code: "A2", name: "Work", path: "A - Productivity / A2 Work", parent: "A" },
    { code: "A3", name: "Study Material", path: "A - Productivity / A3 Study Material", parent: "A" },
    { code: "A4", name: "Exams", path: "A - Productivity / A4 Exams", parent: "A" },
    { code: "A41", name: "CPR", path: "A - Productivity / A4 Exams / A41 CPR", parent: "A4" },
    { code: "A5", name: "Travel", path: "A - Productivity / A5 Travel", parent: "A" },
    { code: "B", name: "Image", path: "B - Image" },
    { code: "B1", name: "Personal", path: "B - Image / B1 Personal", parent: "B" },
    { code: "B2", name: "Work", path: "B - Image / B2 Work", parent: "B" },
    { code: "B3", name: "Notes", path: "B - Image / B3 Notes", parent: "B" },
    { code: "B4", name: "Wallpaper", path: "B - Image / B4 Wallpaper", parent: "B" },
    { code: "C", name: "Media", path: "C - Media" },
    { code: "C1", name: "Music", path: "C - Media / C1 Music", parent: "C" },
    { code: "C11", name: "Songs", path: "C - Media / C1 Music / C11 Songs", parent: "C1" },
    { code: "C12", name: "Ringtone", path: "C - Media / C1 Music / C12 Ringtone", parent: "C1" },
    { code: "C2", name: "Video", path: "C - Media / C2 Video", parent: "C" },
    { code: "C21", name: "Animate", path: "C - Media / C2 Video / C21 Animate", parent: "C2" },
    { code: "C22", name: "Movie", path: "C - Media / C2 Video / C22 Movie", parent: "C2" },
    { code: "D", name: "Program", path: "D - Program" },
    { code: "D1", name: "Personal", path: "D - Program / D1 Personal", parent: "D" },
    { code: "D2", name: "Work", path: "D - Program / D2 Work", parent: "D" },
    { code: "E", name: "Games", path: "E - Games" },
    { code: "E1", name: "Minecraft", path: "E - Games / E1 Minecraft", parent: "E" },
    { code: "E11", name: "Save", path: "E - Games / E1 Minecraft / E11 Save", parent: "E1" },
    { code: "E12", name: "Mod", path: "E - Games / E1 Minecraft / E12 Mod", parent: "E1" },
    { code: "E13", name: "Skin", path: "E - Games / E1 Minecraft / E13 Skin", parent: "E1" },
    { code: "E2", name: "Euro Truck Simulator 2", path: "E - Games / E2 Euro Truck Simulator 2", parent: "E" },
    { code: "E3", name: "Cities Skylines 2", path: "E - Games / E3 Cities Skylines 2", parent: "E" },
    { code: "E4", name: "Satisfactory", path: "E - Games / E4 Satisfactory", parent: "E" },
    { code: "F", name: "Finance", path: "F - Finance" },
    { code: "F1", name: "E-Bills", path: "F - Finance / F1 E-Bills", parent: "F" },
    { code: "F2", name: "Bank Statement", path: "F - Finance / F2 Bank Statement", parent: "F" },
    { code: "F3", name: "Email Confirmation", path: "F - Finance / F3 Email Confirmation", parent: "F" },
    { code: "G", name: "Peoples", path: "G - Peoples" },
    { code: "G1", name: "Self", path: "G - Peoples / G1 Self", parent: "G" },
    { code: "G2", name: "Serena", path: "G - Peoples / G2 Serena", parent: "G" },
    { code: "G3", name: "Family", path: "G - Peoples / G3 Family", parent: "G" },
    { code: "G4", name: "Company", path: "G - Peoples / G4 Company", parent: "G" },
    { code: "G5", name: "Other People", path: "G - Peoples / G5 Other People", parent: "G" },
    { code: "H", name: "Household Affair", path: "H - Household Affair" },
    { code: "H1", name: "Instruction manuals", path: "H - Household Affair / H1 Instruction manuals", parent: "H" },
    { code: "H2", name: "Household Finance", path: "H - Household Affair / H2 Household Finance", parent: "H" },
    { code: "H3", name: "Asset", path: "H - Household Affair / H3 Asset", parent: "H" },
    { code: "I", name: "Idea", path: "I - Idea" },
    { code: "K", name: "Kreative", path: "K - Kreative" },
    { code: "L", name: "Library", path: "L - Library" },
    { code: "R", name: "Raw", path: "R - Raw" },
    { code: "S", name: "Special Event", path: "S - Special Event" },
    { code: "T", name: "Temporary", path: "T - Temporary" },
    { code: "U", name: "Unsorted", path: "U - Unsorted" },
    { code: "V", name: "Device Backup", path: "V - Device Backup" },
    { code: "X", name: "One-off Event", path: "X - One-off Event" },
    { code: "Z", name: "Quick Access", path: "Z - Quick Access" },
  ];

  function parseHomeSegment(segment) {
    const text = String(segment || "").trim();
    if (!text) return null;
    let match = text.match(/^([A-Za-z]\d*)\s*-\s*(.+)$/);
    if (match) {
      return { code: match[1], name: match[2].trim(), label: text };
    }
    match = text.match(/^([A-Za-z]\d*)\s+(.+)$/);
    if (match) {
      return { code: match[1], name: match[2].trim(), label: text };
    }
    return { code: null, name: text, label: text };
  }

  function leavesFromHomePath(homePath) {
    const parts = String(homePath || "")
      .split(/\s*\/\s*/)
      .map(function (part) {
        return part.trim();
      })
      .filter(Boolean);
    const leaves = [];
    let pathSoFar = "";
    let parentCode;

    parts.forEach(function (part) {
      const parsed = parseHomeSegment(part);
      if (!parsed) return;
      pathSoFar = pathSoFar ? pathSoFar + " / " + parsed.label : parsed.label;
      const code = parsed.code || "custom:" + pathSoFar;
      const leaf = {
        code: code,
        name: parsed.name,
        path: pathSoFar,
      };
      if (parentCode) leaf.parent = parentCode;
      if (!parsed.code) leaf.custom = true;
      leaves.push(leaf);
      parentCode = code;
    });

    return leaves;
  }

  function segmentSortKey(segment) {
    const parsed = parseHomeSegment(segment);
    if (!parsed) return { letter: "", num: 0, rest: String(segment || "") };
    const code = parsed.code || "";
    const match = code.match(/^([A-Za-z]+)(\d*)$/);
    return {
      letter: match ? match[1].toUpperCase() : parsed.name.toUpperCase(),
      num: match && match[2] ? parseInt(match[2], 10) : 0,
      rest: (parsed.name || segment || "").toLowerCase(),
    };
  }

  function compareSegments(a, b) {
    if (a === b) return 0;
    const ka = segmentSortKey(a);
    const kb = segmentSortKey(b);
    if (ka.letter !== kb.letter) return ka.letter < kb.letter ? -1 : 1;
    if (ka.num !== kb.num) return ka.num - kb.num;
    if (ka.rest !== kb.rest) return ka.rest < kb.rest ? -1 : 1;
    return a < b ? -1 : 1;
  }

  function compareLeafPaths(aPath, bPath) {
    const aParts = String(aPath || "")
      .split(/\s*\/\s*/)
      .filter(Boolean);
    const bParts = String(bPath || "")
      .split(/\s*\/\s*/)
      .filter(Boolean);
    const len = Math.min(aParts.length, bParts.length);
    for (let i = 0; i < len; i += 1) {
      const cmp = compareSegments(aParts[i], bParts[i]);
      if (cmp !== 0) return cmp;
    }
    return aParts.length - bParts.length;
  }

  function sortLeavesByFolder(leaves) {
    return (leaves || []).slice().sort(function (a, b) {
      return compareLeafPaths(a.path, b.path);
    });
  }

  function mergeManualLeaves(baseLeaves, homePaths) {
    const byPath = new Map();
    (baseLeaves || []).forEach(function (leaf) {
      byPath.set(leaf.path, Object.assign({}, leaf));
    });

    (homePaths || []).forEach(function (home) {
      leavesFromHomePath(home).forEach(function (leaf) {
        if (!byPath.has(leaf.path)) byPath.set(leaf.path, leaf);
      });
    });

    return sortLeavesByFolder(Array.from(byPath.values()));
  }

  global.FilingMap = global.FilingMap || {};
  global.FilingMap.MANUAL_LEAVES = MANUAL_LEAVES;
  global.FilingMap.parseHomeSegment = parseHomeSegment;
  global.FilingMap.leavesFromHomePath = leavesFromHomePath;
  global.FilingMap.compareLeafPaths = compareLeafPaths;
  global.FilingMap.sortLeavesByFolder = sortLeavesByFolder;
  global.FilingMap.mergeManualLeaves = mergeManualLeaves;
  global.FilingMap.listManualLeaves = function listManualLeaves(homePaths) {
    return mergeManualLeaves(
      MANUAL_LEAVES.map(function (leaf) {
        return Object.assign({}, leaf);
      }),
      homePaths || [],
    );
  };
})(typeof window !== "undefined" ? window : globalThis);
